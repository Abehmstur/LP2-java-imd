public class TurmaVIEW {
    Prova provaUm = new Prova();
    Prova provaDois = new Prova();

    Aluno aluno1 = new Aluno();
    Aluno aluno2 = new Aluno();
    Aluno aluno3 = new Aluno();
    

    aluno1.setProva1(provaUm.setNotaParte1(6.0));
    aluno1.setProva1(provaUm.setNotaParte2(0.5));
    aluno1.setProva2(provaDois.setNotaParte1(7.0));
    aluno1.setProva2(provaDois.setNotaParte2(1.0));
    
    aluno2.setProva1(provaUm.setNotaParte1(9.0));
    aluno2.setProva1(provaUm.setNotaParte2(0.5));
    aluno2.setProva2(provaDois.setNotaParte1(2.0));
    aluno2.setProva2(provaDois.setNotaParte2(1.0));

    aluno3.setProva1(provaUm.setNotaParte1(7.0));
    aluno3.setProva1(provaUm.setNotaParte2(0.5));
    aluno3.setProva2(provaDois.setNotaParte1(8.0));
    aluno3.setProva2(provaDois.setNotaParte2(1.0));

    Turma turma0 = new Turma();

    turma0.adicionarAlunoTurma(aluno1);
    turma0.adicionarAlunoTurma(aluno2);
    turma0.adicionarAlunoTurma(aluno3);

    System.out.println("Nota Total das Provas: Prova1: " + aluno1.provaUm.calcularNotaTotal());
    System.out.println("Nota Total das Provas: Prova2: " + aluno1.provaDois.calcularNotaTotal());

}