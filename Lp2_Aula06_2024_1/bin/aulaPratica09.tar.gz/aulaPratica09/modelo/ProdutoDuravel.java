package aulaPratica09.modelo;

public class ProdutoDuravel extends Produto{
	private int	durabilidade;
	
	public ProdutoDuravel() {
		super();
	}

	public int getDurabilidade() {
		return durabilidade;
	}

	public void setDurabilidade(int durabilidade) {
		this.durabilidade = durabilidade;
	}
}
